# Daybook 4.0 – Android app

Developed by Farzad Raza, Badloon Technology & Academy (0745 616 316).

Daily expenses, income, profit and notes. Works offline; data stays on the phone.
English, Dari and Pashto. Reports (week / month / year) with PDF export, history search,
backup to phone + automatic backup, restore (list, file picker, or open a backup from
WhatsApp/Telegram/Files), Excel (CSV) export, light/dark theme.

Runs on Android 5.0 (API 21) up to Android 16 (API 36). App ID: com.badloon.daybook

## Build (GitHub Actions)
`.github/workflows/build-apk.yml` unzips Daybook-android.zip and runs `build.sh`, which
builds `Daybook.apk` (install on a phone) and `Daybook.aab` (upload to Google Play).
To release a new version: upload the new Daybook-android.zip; the workflow file never changes.

The app is signed with `app/daybook.keystore`. Keep this repository private
(the key and its password are in `app/build.gradle`).
