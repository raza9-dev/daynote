#!/usr/bin/env bash
# Builds Daybook.apk (to install on a phone) and Daybook.aab (for Google Play).
# Called by .github/workflows/build-apk.yml. Usage: bash build.sh <output-folder>
set -eu
cd "$(dirname "$0")"
OUT="${1:-$PWD/out}"

GV=$(sed -n 's/.*gradle-\([0-9.]*\)-bin\.zip.*/\1/p' gradle/wrapper/gradle-wrapper.properties)
echo "Using Gradle $GV"
if [ ! -x "/tmp/gradle-$GV/bin/gradle" ]; then
  curl -sSL -o /tmp/gradle.zip "https://services.gradle.org/distributions/gradle-$GV-bin.zip"
  unzip -q -o /tmp/gradle.zip -d /tmp
fi

if command -v sdkmanager >/dev/null 2>&1; then
  (yes | sdkmanager --licenses >/dev/null 2>&1) || true
fi

"/tmp/gradle-$GV/bin/gradle" assembleRelease bundleRelease --no-daemon --stacktrace

mkdir -p "$OUT"
cp app/build/outputs/apk/release/app-release.apk "$OUT/Daybook.apk"
cp app/build/outputs/bundle/release/app-release.aab "$OUT/Daybook.aab"
echo "Done: $OUT/Daybook.apk and $OUT/Daybook.aab"
